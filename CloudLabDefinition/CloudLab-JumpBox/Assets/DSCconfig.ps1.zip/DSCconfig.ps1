﻿configuration DSCconfig
{ 
    param ( 
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xDisk, xPendingReboot, cDisk

    Node localhost
    {
        LocalConfigurationManager
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        } 

        xWaitforDisk Disk2
        {
                DiskNumber = 2
                RetryIntervalSec = $RetryIntervalSec
                RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "E"
        }

        WindowsFeature RSATTools
        { 
            DependsOn= '[WindowsFeature]ADDSInstall'
            Ensure = 'Present'
            Name = 'RSAT'
            IncludeAllSubFeature = $true
        }
    }
} 